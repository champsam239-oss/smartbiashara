// Edge Function: plain-language explanation of figures the DATABASE computed. The API key exists only as a server secret:
//   supabase secrets set ANTHROPIC_API_KEY=...   (never put it in .env, VITE_ variables, or source code)
// Runs with the CALLER's session, so row-level security limits it to the caller's own business. Sends totals only: no names, phones or product lists.
import { createClient } from 'npm:@supabase/supabase-js@2'

const cors = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type' }
const json = (b: unknown, status = 200) => new Response(JSON.stringify(b), { status, headers: { ...cors, 'Content-Type': 'application/json' } })
const day = (d: Date) => d.toISOString().slice(0, 10)
const kes = (m: number) => Math.round(m) / 100

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors })
  try {
    const key = Deno.env.get('ANTHROPIC_API_KEY')
    if (!key) return json({ configured: false })
    const db = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_ANON_KEY')!, { global: { headers: { Authorization: req.headers.get('Authorization') ?? '' } } })
    const { data: u } = await db.auth.getUser()
    if (!u.user) return json({ error: 'Please sign in again.' }, 401)
    const { business_id: biz } = await req.json()
    const { data: mem } = await db.from('memberships').select('role').eq('business_id', biz).eq('user_id', u.user.id).maybeSingle()
    if (!mem) return json({ error: 'Not allowed.' }, 403)

    const t = new Date(Date.now() + 3 * 3600000), at = (n: number) => day(new Date(t.getTime() + n * 86400000))
    const rep = (a: string, b: string) => db.rpc('profit_report', { p_business: biz, p_from: `${a}T00:00:00+03:00`, p_to: `${day(new Date(Date.parse(b) + 86400000))}T00:00:00+03:00` })
    const [now, prev, bal, prods] = await Promise.all([rep(at(-6), at(0)), rep(at(-13), at(-7)), db.rpc('customer_balances', { p_business: biz }), db.from('products').select('stock_qty,min_stock').eq('business_id', biz).eq('active', true)])
    const n = now.data?.[0], p = prev.data?.[0]
    if (!n || !p) return json({ error: 'Not enough data yet.' }, 400)
    const od = (bal.data ?? []).filter((x: { overdue_minor: number }) => x.overdue_minor > 0)
    const facts = {
      currency: 'KES', this_week: { sales: kes(n.net_sales_minor), gross_profit: kes(n.gross_profit_minor), expenses: kes(n.expenses_minor), estimated_net_profit: kes(n.net_profit_minor), cash_collected: kes(n.cash_collected_minor), unpaid_credit: kes(n.unpaid_credit_minor) },
      last_week: { sales: kes(p.net_sales_minor), expenses: kes(p.expenses_minor), estimated_net_profit: kes(p.net_profit_minor) },
      products_at_or_below_minimum_stock: (prods.data ?? []).filter((x: { stock_qty: number; min_stock: number }) => x.stock_qty <= x.min_stock).length,
      customers_with_overdue_balance: od.length, overdue_total: kes(od.reduce((s: number, x: { overdue_minor: number }) => s + x.overdue_minor, 0)),
    }
    const r = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST', headers: { 'content-type': 'application/json', 'x-api-key': key, 'anthropic-version': '2023-06-01' },
      body: JSON.stringify({
        model: Deno.env.get('AI_MODEL') ?? 'claude-sonnet-5-5', max_tokens: 400,
        system: 'You explain a small shop owner\'s weekly figures in simple English, in at most 4 short sentences. Use ONLY the numbers given. Do not invent figures, do not predict the future, do not promise outcomes, and say these are estimates based on recorded data. Amounts are Kenyan shillings (KES). Mention anything that needs attention (low stock, overdue debts, expenses rising).',
        messages: [{ role: 'user', content: JSON.stringify(facts) }],
      }),
    })
    if (!r.ok) return json({ error: 'The AI service is not available right now. Standard insights are still shown.' }, 502)
    const out = await r.json()
    const text = (out.content ?? []).filter((c: { type: string }) => c.type === 'text').map((c: { text: string }) => c.text).join(' ').trim()
    return json({ configured: true, text, figures: facts })
  } catch (_e) {
    return json({ error: 'Something went wrong. Please try again.' }, 500)
  }
})
