#!/bin/sh
# Fails if an API key or privileged key appears in front-end source, public files or the build output.
if grep -rIEn "sk-ant-|service_role|ANTHROPIC_API_KEY|eyJhbGciOi[A-Za-z0-9_-]{20,}" src public dist .env.example 2>/dev/null | grep -v "^.*# "; then
  echo "Possible secret found. Remove it and rotate the key."; exit 1
fi
echo "No secrets found in client code."
